<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Project main file</title>
        <!-- <link rel="stylesheet" href="style2.css"> -->
</head>
</head>
<body>
        <?php include("./client/header.php"); ?>
        <img src="public/booking.jpg" alt="style">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Obcaecati inventore excepturi fugiat suscipit, recusandae omnis. Incidunt, laboriosam, quam tenetur aspernatur accusantium modi nemo rem a aliquid numquam voluptatum inventore unde.
        Voluptate praesentium expedita perspiciatis id voluptatem assumenda perferendis corrupti debitis iure explicabo recusandae molestias modi natus quibusdam molestiae sit tempora tenetur labore vero totam asperiores cumque, vitae omnis. Repudiandae, velit.
        Illo harum sint dolorem culpa accusamus, numquam excepturi impedit repellendus quis vitae facilis minima, nulla molestias qui repudiandae maxime earum! Doloremque deleniti accusamus perspiciatis non magnam velit! Facilis, quaerat voluptatem.
        Mollitia quibusdam suscipit illum beatae sint quo sunt perferendis velit, ipsum dolores quos itaque ullam animi minima fugiat est amet, fuga, blanditiis rerum placeat exercitationem sapiente quidem quae. Quod, iste.
        Eligendi distinctio debitis nisi corrupti perferendis ipsam voluptates ratione aliquid voluptate natus ipsum, libero quidem hic. Fugiat quod esse aliquam minus, commodi velit maxime ipsum suscipit voluptate possimus assumenda nam!
        Facilis consequuntur unde quibusdam, laborum nisi iusto odio fuga velit deleniti rerum vel eum, error id pariatur eos aliquam reiciendis corrupti dolorum! Itaque sed quas fuga unde, eius placeat culpa.
        Harum, dolor numquam laboriosam ex sequi incidunt cumque, omnis odio provident quas, hic tempore assumenda nihil! Expedita sed necessitatibus ea nulla animi suscipit, autem quasi magni non. Adipisci, vel modi?
  <!-- <section class="hero-slider">
  <div class="slides">
    <div class="slide active" style="background-image: url('public/booking.jpg')"></div>
    <div class="slide" style="background-image: url('public/booking.jpg')"></div>
    <div class="slide" style="background-image: url('public/booking.jpg')"></div>
  </div>

  <div class="overlay-content">
    <h2>BOOK A ROOM ONLINE</h2>
    <form class="booking-form" onsubmit="return false;">
      <div class="field">
        <label>Arrival</label>
        <input type="date" name="arrival" required />
      </div>
      <div class="field">
        <label>Departure</label>
        <input type="date" name="departure" required />
      </div>
      <button class="book-btn">Book Now</button>
    </form>
  </div>

  <div class="dots">
    <span class="dot active" onclick="goToSlide(0)"></span>
    <span class="dot" onclick="goToSlide(1)"></span>
    <span class="dot" onclick="goToSlide(2)"></span>
  </div>
</section>

<script src="script.js"></script> -->
        
</body>
</html>