const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');
let current = 0;

function goToSlide(idx) {
  slides[current].classList.remove('active');
  dots[current].classList.remove('active');
  current = idx;
  slides[current].classList.add('active');
  dots[current].classList.add('active');
}

function nextSlide() {
  let next = (current + 1) % slides.length;
  goToSlide(next);
}

// Auto-slide every 5 seconds
setInterval(nextSlide, 5000);