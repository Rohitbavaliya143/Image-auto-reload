<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Online Book</title>
        <link rel="stylesheet" href="css/fontawesome-free-6.5.2-web/css/all.min.css">
        <link rel="stylesheet" href="./style.css" />
</head>
<body>
        <nav>
                
                <div class="menu">
                        <input type="checkbox" id="check">
                        <div class="logo"> <li><a href="#">RiverBook</a></li></div>
                        <ul>    
                                <label  class="button cancel" for="check"><i class="fas fa-times"></i></label> 
                                <li><a href="#">HOME</a></li>
                                <li><a href="#">ABOUT</a></li>
                                <li><a href="#">OUR ROOM</a></li>
                                <li><a href="#">BLOG</a></li>
                                <li><a href="#">CONTACT US</a></li>
                                 <div class="auth-button">
                                        <button type="submit" id="lg">Login</button>
                                        <button type="submit" id="lg">Sign up</button>
                                </div>
                        </ul>
                        <label class="button bars" for="check"><i class="fas fa-bars"></i></label>
                </div>
               
        </nav>
</body>
</html>